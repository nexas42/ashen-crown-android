package com.pickl_rick42.velvetoaths;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

final class GameView extends View {
    private final Paint p = new Paint(3);
    private final Paint shade = new Paint();
    private final GameState state;
    private final ArrayList<RectF> buttons = new ArrayList<>();
    private Bitmap ball, pact, after;
    private String toast = "";
    private long toastUntil = 0;
    private int screen = 0; // story, paths, about, safety
    private final float den;

    GameView(Context context) {
        super(context);
        den = getResources().getDisplayMetrics().density;
        state = new GameState(context);
        ball = load(context, "scene_ball");
        pact = load(context, "scene_pact");
        after = load(context, "scene_after");
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private Bitmap load(Context context, String name) {
        int id = getResources().getIdentifier(name, "drawable", context.getPackageName());
        return BitmapFactory.decodeResource(getResources(), id);
    }

    private float d(float value) { return value * den; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        buttons.clear();
        p.setColor(0xFF0D090D);
        canvas.drawRect(0, 0, getWidth(), getHeight(), p);
        if (screen == 1) drawPaths(canvas);
        else if (screen == 2) drawInfo(canvas, false);
        else if (screen == 3) drawInfo(canvas, true);
        else drawStory(canvas, state.scene == 0 ? Story.title(state) : Story.page(state));
    }

    private void drawStory(Canvas c, Story.Page page) {
        int imageH = (int)Math.min(getHeight() * .31f, d(260));
        Bitmap art = "pact".equals(page.image) ? pact : "after".equals(page.image) ? after : ball;
        if (art != null) {
            Rect src = new Rect(0, 0, art.getWidth(), art.getHeight());
            Rect dst = new Rect(0, 0, getWidth(), imageH);
            c.drawBitmap(art, src, dst, p);
        }
        LinearGradient fade = new LinearGradient(0, imageH * .35f, 0, imageH,
                0x00130B12, 0xFF130B12, Shader.TileMode.CLAMP);
        shade.setShader(fade);
        c.drawRect(0, 0, getWidth(), imageH + 2, shade);
        shade.setShader(null);

        float x = d(22), width = getWidth() - d(44);
        float y = imageH - d(34);
        text(c, page.chapter, x, y, d(11), 0xFFE3AE67, true);
        y += d(32);
        float titleSize = fitSingleLine(page.title, width, d(30), d(21), true);
        text(c, page.title, x, y, titleSize, 0xFFFFEBDD, true);
        y += d(16);

        if (state.scene > 0 && state.scene < 10) {
            drawStats(c, y);
            y += d(40);
        }

        float buttonH = d(48), gap = d(8), bottom = getHeight() - d(18);
        float totalButtons = page.choices.length * buttonH + (page.choices.length - 1) * gap;
        float buttonTop = bottom - totalButtons;
        float availableBody = Math.max(d(42), buttonTop - y - d(15));
        float bodySize = fitBody(page.body, width, availableBody, d(16), d(11.5f), 1.40f);
        wrap(c, page.body, x, y, width, bodySize, 0xFFE7D9D3, false, 1.40f);

        float by = buttonTop;
        for (String choice : page.choices) {
            RectF rect = new RectF(x, by, getWidth() - x, by + buttonH);
            button(c, rect, choice);
            buttons.add(rect);
            by += buttonH + gap;
        }

        if (System.currentTimeMillis() < toastUntil) {
            p.setColor(0xF02D1725);
            RectF r = new RectF(d(12), d(16), getWidth() - d(12), d(64));
            c.drawRoundRect(r, d(12), d(12), p);
            float ts = fitSingleLine(toast, r.width() - d(30), d(13), d(10), false);
            text(c, toast, d(26), d(47), ts, 0xFFFFEBDD, false);
            postInvalidateDelayed(180);
        }
    }

    private void drawStats(Canvas c, float y) {
        text(c, state.path, d(22), y + d(18), d(11), 0xFFE3AE67, true);
        String stats = "TRUST " + state.trust + "   DESIRE " + state.heat + "   CLARITY " + state.clarity;
        float size = fitSingleLine(stats, getWidth() - d(145), d(12), d(9), false);
        text(c, stats, d(132), y + d(18), size, 0xFFFFEBDD, false);
        p.setColor(0xFF5D263F);
        c.drawRect(d(22), y + d(27), getWidth() - d(22), y + d(30), p);
    }

    private void drawPaths(Canvas c) {
        text(c, "CHOOSE YOUR APPROACH", d(22), d(52), d(11), 0xFFE3AE67, true);
        text(c, "How do you enter the pact?", d(22), d(90), d(25), 0xFFFFEBDD, true);
        String[] names = {"CHALLENGER", "DEVOTEE", "OBSERVER"};
        String[] descriptions = {
                "Playful resistance, sharp wit, and a taste for earning every surrender.",
                "Open desire, emotional honesty, and strength found in freely chosen trust.",
                "Careful attention, clear language, and the confidence to set the pace."
        };
        float y = d(122), cardH = Math.min(d(125), (getHeight() - d(175)) / 3f);
        for (int i = 0; i < 3; i++) {
            RectF r = new RectF(d(20), y, getWidth() - d(20), y + cardH);
            p.setColor(i == 0 ? 0xFF34202C : i == 1 ? 0xFF3B1D2E : 0xFF29222F);
            c.drawRoundRect(r, d(14), d(14), p);
            text(c, names[i], d(38), y + d(32), d(17), 0xFFE3AE67, true);
            float size = fitBody(descriptions[i], r.width() - d(36), cardH - d(48), d(14), d(11), 1.3f);
            wrap(c, descriptions[i], d(38), y + d(58), r.width() - d(36), size, 0xFFE9D9D4, false, 1.3f);
            buttons.add(r);
            y += cardH + d(10);
        }
        text(c, "All characters are fictional adults · Progress autosaves",
                d(22), getHeight() - d(20), d(10), 0xFF9D8F94, false);
    }

    private void drawInfo(Canvas c, boolean safety) {
        text(c, safety ? "CONTENT & SAFETY" : "ABOUT", d(22), d(55), d(11), 0xFFE3AE67, true);
        text(c, safety ? "The Rules Behind the Masks" : "Velvet Oaths",
                d(22), d(98), d(26), 0xFFFFEBDD, true);
        String body;
        if (safety) {
            body = "ADULTS ONLY\n\nEvery named character is fictional and explicitly aged 29–35. The story contains sensual themes, consensual power exchange, and negotiated consensual non-consent roleplay.\n\nThe roleplay is never actual non-consent. Characters agree on limits first, use green/yellow/red check-ins, and share the safeword Ember. Any character may pause or stop without punishment. Intimate moments fade to black; no explicit sex acts are shown.";
        } else {
            body = "An original adults-only, text-and-illustration dark-romance game.\n\nCreated by @pickl_rick42\n\nRecurring cast:\nLysara Vale, 29 — composed, commanding, attentive.\nKael Marr, 32 — guarded, protective, tender.\nSeraphine Roan, 35 — witty, observant, honest.\n\nNo music, advertisements, analytics, accounts, or internet connection required.\n\nVersion 2.0.0";
        }
        float top = d(130), buttonTop = getHeight() - d(76);
        float size = fitBody(body, getWidth() - d(44), buttonTop - top - d(18), d(16), d(11), 1.45f);
        wrap(c, body, d(22), top, getWidth() - d(44), size, 0xFFE7D9D3, false, 1.45f);
        RectF r = new RectF(d(22), buttonTop, getWidth() - d(22), getHeight() - d(22));
        button(c, r, "Back");
        buttons.add(r);
    }

    private void button(Canvas c, RectF r, String label) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF2C1B26);
        c.drawRoundRect(r, d(11), d(11), p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(d(1));
        p.setColor(0xFF76536A);
        c.drawRoundRect(r, d(11), d(11), p);
        p.setStyle(Paint.Style.FILL);
        float size = fitSingleLine(label, r.width() - d(54), d(14), d(9.5f), true);
        text(c, label, r.left + d(16), r.centerY() + size * .34f, size, 0xFFFFEBDD, true);
        text(c, "›", r.right - d(23), r.centerY() + d(6), d(20), 0xFFE3AE67, true);
    }

    private float fitSingleLine(String value, float width, float start, float min, boolean bold) {
        p.setTypeface(Typeface.create("serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        float size = start;
        while (size > min) {
            p.setTextSize(size);
            if (p.measureText(value) <= width) break;
            size -= d(.5f);
        }
        return size;
    }

    private float fitBody(String value, float width, float height, float start, float min, float spacing) {
        float size = start;
        while (size > min) {
            int lines = wrappedLineCount(value, width, size, false);
            if (lines * size * spacing <= height) break;
            size -= d(.5f);
        }
        return size;
    }

    private int wrappedLineCount(String value, float width, float size, boolean bold) {
        p.setTypeface(Typeface.create("serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        p.setTextSize(size);
        int count = 0;
        for (String paragraph : value.split("\n", -1)) {
            if (paragraph.isEmpty()) { count++; continue; }
            String line = "";
            for (String word : paragraph.split(" ")) {
                String next = line.isEmpty() ? word : line + " " + word;
                if (p.measureText(next) > width && !line.isEmpty()) {
                    count++;
                    line = word;
                } else line = next;
            }
            count++;
        }
        return count;
    }

    private void text(Canvas c, String value, float x, float y, float size, int color, boolean bold) {
        p.setTypeface(Typeface.create("serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        p.setTextSize(size);
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        c.drawText(value, x, y, p);
    }

    private float wrap(Canvas c, String value, float x, float y, float width,
                       float size, int color, boolean bold, float spacing) {
        p.setTypeface(Typeface.create("serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        p.setTextSize(size);
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        float lineHeight = size * spacing;
        for (String paragraph : value.split("\n", -1)) {
            if (paragraph.isEmpty()) { y += lineHeight; continue; }
            String line = "";
            for (String word : paragraph.split(" ")) {
                String next = line.isEmpty() ? word : line + " " + word;
                if (p.measureText(next) > width && !line.isEmpty()) {
                    c.drawText(line, x, y, p);
                    y += lineHeight;
                    line = word;
                } else line = next;
            }
            c.drawText(line, x, y, p);
            y += lineHeight;
        }
        return y - lineHeight;
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP) return true;
        for (int i = 0; i < buttons.size(); i++) {
            if (buttons.get(i).contains(event.getX(), event.getY())) {
                tap(i);
                break;
            }
        }
        return true;
    }

    private void tap(int index) {
        if (screen == 1) {
            if (index < 3) {
                state.newGame(index == 0 ? "CHALLENGER" : index == 1 ? "DEVOTEE" : "OBSERVER");
                screen = 0;
                toast = "The masquerade begins.";
                toastUntil = System.currentTimeMillis() + 1700;
            }
        } else if (screen == 2 || screen == 3) {
            screen = 0;
        } else {
            String result = Story.choose(state, index);
            if ("paths".equals(result)) screen = 1;
            else if ("about".equals(result)) screen = 2;
            else if ("safety".equals(result)) screen = 3;
            else if (!result.isEmpty() && !"continue".equals(result)) {
                toast = result;
                toastUntil = System.currentTimeMillis() + 2600;
            }
        }
        invalidate();
    }
}
