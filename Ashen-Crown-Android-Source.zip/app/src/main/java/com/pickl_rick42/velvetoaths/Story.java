package com.pickl_rick42.velvetoaths;

final class Story {
    static final class Page {
        final String chapter, title, body, image;
        final String[] choices;
        Page(String chapter, String title, String body, String image, String... choices) {
            this.chapter = chapter; this.title = title; this.body = body;
            this.image = image; this.choices = choices;
        }
    }

    static Page page(GameState s) {
        switch (s.scene) {
            case 1:
                return new Page("ACT I · THE MASQUERADE", "Three Faces at Midnight",
                        "Lady Lysara Vale, twenty-nine, rules the ballroom with patient confidence. Kael Marr, thirty-two, watches behind a black mask—guarded, loyal, and softer than his scar suggests. Seraphine Roan, thirty-five, notices everything and smiles as if she already knows your answer.",
                        "ball", "Accept Lysara's invitation", "Ask Kael to walk with you", "Let Seraphine introduce you");
            case 2:
                return new Page("BEFORE THE GAME", "Terms Before Temptation",
                        "In a quiet alcove, all four adults negotiate the scene. The fantasy may sound dangerous; the reality will not be. Green means continue, yellow means slow down, and Ember ends everything immediately. Anyone may change their mind at any time.",
                        "pact", "Sign the written pact", "Add a boundary first", "Choose conversation only");
            case 3:
                return new Page("THE MASKED WAGER", "A Command in Public",
                        "Lysara's amber eyes hold yours. Within the agreed performance, she asks you to surrender your dance card until midnight. Kael stays close enough to help; Seraphine watches for your check-in signal.",
                        "ball", "Hand her the card", "Make her earn it", "Decline with a smile");
            case 4:
                return new Page("THE PRIVATE CHAMBER", "The Velvet Pact",
                        "The door closes, but never locks. Signed limits remain on the table. Lysara repeats your safeword; Kael asks how you want him involved; Seraphine confirms that watching is participation only when freely chosen. Candlelight warms the charged silence.",
                        "pact", "Invite all three closer", "Choose Lysara and Kael", "Keep the scene verbal");
            case 5:
                return new Page("KAEL · AGE 32", "What His Silence Means",
                        "Kael admits that restraint is his choice, not weakness. He trusts slowly and protects fiercely. When your fingers meet his gloved hand, he asks—not assumes—whether you want him to stay.",
                        "pact", "Ask him to stay", "Ask for more time", "Invite Seraphine to guide you");
            case 6:
                return new Page("SERAPHINE · AGE 35", "The Honest Witness",
                        "Seraphine's humor softens the room. She reads the pact aloud, catches one ambiguous phrase, and rewrites it plainly. Desire matters to her, but clarity matters more.",
                        "pact", "Thank her and continue", "Negotiate a slower pace", "End the scene for tonight");
            case 7:
                return new Page("CNC ROLEPLAY · CONSENSUAL", "The Veiled Scene",
                        "Within the agreed fiction, Lysara plays the dangerous captor and you answer in character. Outside the fiction, her thumb taps the check-in rhythm against your palm. Every look asks the same real question: continue? The intimate moment fades behind the velvet curtain.",
                        "pact", "Answer green and continue", "Answer yellow and slow down", "Say Ember and stop");
            case 8:
                return new Page("AFTERCARE", "When the Masks Come Off",
                        "The performance ends. Water, warm blankets, and quiet replace the charged words. Nobody treats stopping as failure. Lysara listens, Kael stays near without crowding you, and Seraphine checks what should change next time.",
                        "after", "Talk through every feeling", "Choose quiet closeness", "Ask for space and reassurance");
            case 9:
                return new Page("ACT III · DAWN", "Choose the Next Oath",
                        "Moonlight pales over the balcony. The three adults offer no ownership, only an invitation: a relationship shaped by honesty, appetite, and the right to say no without punishment.",
                        "after", "Form a four-person pact", "Choose one bond for now", "Remain friends and confidants");
            case 10:
                return ending(s, "The Velvet Constellation",
                        "You choose one another without pretending choice has ended. Lysara brings steadiness, Kael fierce tenderness, and Seraphine bright honesty. Your future is negotiated, renewed, and desired.");
            case 11:
                return ending(s, "One Flame, Carefully Held",
                        "You choose depth over speed. The others remain trusted friends while one bond grows at its own pace. Nothing is lost by choosing only what feels true.");
            case 12:
                return ending(s, "The Unbroken Mask",
                        "You keep your independence and their confidence. The masquerade becomes a private tradition—sometimes intimate, sometimes playful, always freely chosen.");
            default:
                return title(s);
        }
    }

    static Page title(GameState s) {
        String body = "A consensual dark-fantasy romance. All characters are fictional adults aged 29–35. Includes negotiated CNC roleplay, power exchange, boundaries, safewords, and aftercare. No actual non-consent.";
        if (s.hasSave()) {
            return new Page("ADULTS 18+ · FICTIONAL CAST", "VELVET OATHS", body, "ball",
                    "Continue the story", "Begin again", "Content & safety", "About");
        }
        return new Page("ADULTS 18+ · FICTIONAL CAST", "VELVET OATHS", body, "ball",
                "I am 18+ · Begin", "Content & safety", "About");
    }

    private static Page ending(GameState s, String title, String body) {
        return new Page("YOUR ENDING", title,
                body + "\n\nTrust " + s.trust + "   Desire " + s.heat + "   Clarity " + s.clarity,
                "after", "Return to title", "Begin another story");
    }

    static String choose(GameState s, int i) {
        if (s.scene == 0) {
            if (s.hasSave()) {
                if (i == 0) return "continue";
                if (i == 1) return "paths";
                if (i == 2) return "safety";
                return "about";
            }
            if (i == 0) return "paths";
            if (i == 1) return "safety";
            return "about";
        }

        String note = "";
        switch (s.scene) {
            case 1:
                s.trust += i == 2 ? 2 : 1; s.heat += i == 0 ? 2 : 1; s.scene = 2; break;
            case 2:
                if (i == 0) { s.pact = true; s.trust += 2; s.heat++; s.scene = 3; }
                else if (i == 1) { s.pact = true; s.clarity += 2; s.trust += 2; s.scene = 3; note = "Your boundary is added without argument."; }
                else { s.clarity += 2; s.trust++; s.scene = 5; note = "Conversation is welcomed as a complete choice."; }
                break;
            case 3:
                if (i == 0) { s.heat += 2; s.trust++; }
                else if (i == 1) { s.heat += 2; s.clarity++; }
                else { s.trust += 2; s.clarity += 2; note = "Lysara accepts the no with genuine warmth."; }
                s.scene = 4; break;
            case 4:
                if (i == 0) { s.heat += 3; s.trust += 2; }
                else if (i == 1) { s.heat += 2; s.trust += 2; }
                else { s.clarity += 2; s.trust++; }
                s.scene = 5; break;
            case 5:
                if (i == 0) { s.trust += 3; s.heat++; }
                else if (i == 1) { s.clarity += 2; s.trust += 2; }
                else { s.trust += 2; s.clarity++; }
                s.scene = 6; break;
            case 6:
                if (i == 0) { s.trust += 2; s.heat += 2; s.scene = 7; }
                else if (i == 1) { s.slowed = true; s.clarity += 2; s.trust += 2; s.scene = 7; }
                else { s.stopped = true; s.trust += 3; s.clarity += 2; s.scene = 8; note = "Everyone honors your choice immediately."; }
                break;
            case 7:
                if (i == 0) { s.heat += 3; s.trust += 2; }
                else if (i == 1) { s.slowed = true; s.clarity += 2; s.trust += 2; note = "The pace changes at once."; }
                else { s.stopped = true; s.clarity += 3; s.trust += 3; note = "Ember ends the performance immediately."; }
                s.scene = 8; break;
            case 8:
                if (i == 0) s.clarity += 3;
                else if (i == 1) s.trust += 3;
                else { s.clarity += 2; s.trust += 2; }
                s.scene = 9; break;
            case 9:
                s.scene = i == 0 ? 10 : i == 1 ? 11 : 12; break;
            case 10: case 11: case 12:
                if (i == 0) s.scene = 0;
                else { s.clearStory(); return "paths"; }
                break;
        }
        s.save();
        return note;
    }
}
