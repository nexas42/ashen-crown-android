package com.pickl_rick42.velvetoaths;

import android.content.Context;
import android.content.SharedPreferences;

final class GameState {
    String path = "";
    int scene = 0, trust = 0, heat = 0, clarity = 2;
    boolean pact = false, slowed = false, stopped = false;
    private final SharedPreferences prefs;

    GameState(Context context) {
        prefs = context.getSharedPreferences("velvet_oaths_save", Context.MODE_PRIVATE);
        load();
    }

    void newGame(String chosenPath) {
        path = chosenPath;
        scene = 1;
        trust = "CHALLENGER".equals(path) ? 1 : 2;
        heat = "DEVOTEE".equals(path) ? 2 : 1;
        clarity = "OBSERVER".equals(path) ? 4 : 2;
        pact = slowed = stopped = false;
        save();
    }

    boolean hasSave() { return !path.isEmpty() && scene > 0; }

    void save() {
        prefs.edit().putString("path", path).putInt("scene", scene)
                .putInt("trust", trust).putInt("heat", heat).putInt("clarity", clarity)
                .putBoolean("pact", pact).putBoolean("slowed", slowed)
                .putBoolean("stopped", stopped).apply();
    }

    void load() {
        path = prefs.getString("path", "");
        scene = prefs.getInt("scene", 0);
        trust = prefs.getInt("trust", 0);
        heat = prefs.getInt("heat", 0);
        clarity = prefs.getInt("clarity", 2);
        pact = prefs.getBoolean("pact", false);
        slowed = prefs.getBoolean("slowed", false);
        stopped = prefs.getBoolean("stopped", false);
    }

    void clearStory() {
        prefs.edit().clear().apply();
        path = ""; scene = 0; trust = heat = 0; clarity = 2;
        pact = slowed = stopped = false;
    }
}
