package com.abdulrahman.ashencrown;

import java.util.Random;

final class Story {
    static final class Page {
        final String chapter, title, body, image;
        final String[] choices;
        Page(String c, String t, String b, String img, String... ch) {
            chapter=c; title=t; body=b; image=img; choices=ch;
        }
    }

    static Page page(GameState s) {
        switch (s.scene) {
            case 1: return new Page("CHAPTER I", "The Ashen Road",
                    "For thirteen winters the Crown of Cinders has slept beneath Greywake Keep. Tonight its beacon burns again. You arrive as the last free villages bar their doors—and something vast circles the red moon.",
                    "keep", "Climb the broken causeway", "Search the abandoned camp");
            case 2: return new Page("THE CAUSEWAY", "Steel in the Fog",
                    "Three oathless raiders block the bridge. Their captain wears a silver key at his throat. He lowers his blade, uncertain whether you are prey or prophecy.",
                    "keep", "Challenge him openly [MIGHT]", "Slip through the ruined arch [GRACE]", "Offer 5 gold for passage");
            case 3: return new Page("THE CAMP", "A Dying Scout",
                    "Among cold firepits you find a wounded scout named Mara. She warns that the keep is not haunted—the dead are being commanded. Her satchel bears the crest of the vanished royal wardens.",
                    "keep", "Use a potion to save Mara", "Take the map and continue", "Question her about the Crown [WIT]");
            case 4:
                if (s.enemyMax == 0) startEnemy(s, 18);
                return battlePage(s, "Gate Warden", "A suit of black armor tears itself from the gate. Blue fire fills its empty visor.", "keep");
            case 5: return new Page("CHAPTER II", "The Library Below",
                    "Beyond the gate, a spiral stair descends into an impossible library. Constellations move beneath the floor. At its center floats the Sun Sigil—the only thing said to command the Crown.",
                    "library", "Decode the moving runes [WIT]", "Break the crystal seal [MIGHT]", "Cross the shadowed rafters [GRACE]");
            case 6: return new Page("THE ARCHIVE", "The Keeper's Bargain",
                    "An ancient keeper offers the Sigil in return for one memory: the face of someone you love. Refuse, and its stone guardian will wake.",
                    "library", "Accept the bargain", "Refuse and draw your weapon", "Expose the Keeper's false oath [WIT]");
            case 7:
                if (s.enemyMax == 0) startEnemy(s, 22);
                return battlePage(s, "Astral Guardian", "Stone wings unfold above the archive. Every strike rings like a cathedral bell.", "library");
            case 8: return new Page("CHAPTER III", "The Crimson Summit",
                    "The path ends above the clouds. Veyrath, the last ember wyrm, coils around the Crown. It does not attack. Its voice arrives inside your bones: ‘Break it, and your kingdoms lose their shield. Wear it, and you become their cage.’",
                    "dragon", "Destroy the Crown", "Claim the Crown", "Hear Veyrath's truth");
            case 9:
                if (s.enemyMax == 0) startEnemy(s, 30);
                return battlePage(s, "Veyrath", "The summit ignites. Your final choice must now be written in fire.", "dragon");
            case 10: return ending(s, "The Dawn Unbound", "You shatter the Crown. Magic storms across the horizon, wild and free. The old kingdoms fall—but in their ruins, no throne can command another soul. Songs name you the Crown-Breaker.");
            case 11: return ending(s, "The Golden Cage", "You raise the Crown. Every flame in the valley bends toward you. War ends before sunrise. Peace follows—perfect, silent, and watched by your sleepless eyes.");
            case 12: return ending(s, "The Third Oath", "You learn the dragon was the Crown's prisoner, not its master. Together you bind its power to every living oath freely given. Greywake becomes a sanctuary, and you its first storyteller.");
            case 13: return ending(s, "Ashes Remember", "Your journey ends upon the dark stone, but the choice survives you. Mara carries your tale beyond Greywake, and another traveler takes up the road.");
            default: return pageTitle(s);
        }
    }

    static Page pageTitle(GameState s) {
        return new Page("AN ORIGINAL SOLO RPG", "ASHEN CROWN",
                "A text-and-illustration fantasy adventure\n\nCreated by Abdulrahman Firas Amer",
                "keep", s.hasSave() ? "Continue journey" : "Begin a new journey", "New game", "About");
    }

    private static Page battlePage(GameState s, String enemy, String body, String image) {
        return new Page("BATTLE · " + enemy.toUpperCase(), enemy,
                body + "\n\nEnemy: " + Math.max(0,s.enemyHp) + "/" + s.enemyMax + "   You: " + Math.max(0,s.hp) + "/" + s.maxHp,
                image, "Strike", "Use talent", s.potions > 0 ? "Drink potion ("+s.potions+")" : "Potion pouch empty");
    }

    private static Page ending(GameState s, String title, String body) {
        return new Page("YOUR ENDING", title, body + "\n\nFinal renown: " + s.xp + "   Gold: " + s.gold,
                "dragon", "Return to title", "Begin another legend");
    }

    static String choose(GameState s, int i, Random rng) {
        String msg = "";
        switch (s.scene) {
            case 0:
                if (i==0 && s.hasSave()) return "continue";
                if (i==2) return "about";
                return "classes";
            case 1: s.scene = i==0 ? 2 : 3; break;
            case 2:
                if (i==2 && s.gold>=5) { s.gold-=5; s.scene=4; msg="The captain honors the bargain."; }
                else if (i==2) msg="You do not have enough gold.";
                else { msg=check(s, i==0?"might":"grace", 7, rng); if(msg.startsWith("Success")){s.xp+=10;s.scene=4;} else{s.hp-=4;s.scene=4;} }
                break;
            case 3:
                if(i==0 && s.potions>0){s.potions--;s.mercy=true;s.xp+=15;s.ward=true;s.scene=4;msg="Mara lives. She teaches you a royal ward.";}
                else if(i==0) msg="Your potion pouch is empty.";
                else if(i==1){s.gold+=6;s.scene=4;msg="The map leads past a hidden cache.";}
                else {msg=check(s,"wit",7,rng);if(msg.startsWith("Success")){s.sigil=true;s.xp+=10;msg+=" You learn the Sigil's true name.";}s.scene=4;}
                break;
            case 4: msg=battle(s,i,5,rng); break;
            case 5:
                String stat=i==0?"wit":i==1?"might":"grace"; msg=check(s,stat,8,rng);
                if(msg.startsWith("Success")){s.sigil=true;s.xp+=20;s.scene=8;}else{s.hp-=5;s.scene=6;}
                break;
            case 6:
                if(i==0){s.sigil=true;s.wit=Math.max(1,s.wit-1);s.scene=8;msg="A beloved face fades, but the Sigil is yours.";}
                else if(i==1){startEnemy(s,22);s.scene=7;msg="The guardian wakes.";}
                else {msg=check(s,"wit",9,rng);if(msg.startsWith("Success")){s.sigil=true;s.xp+=25;s.scene=8;}else{startEnemy(s,22);s.scene=7;}}
                break;
            case 7: msg=battle(s,i,8,rng); break;
            case 8:
                if(i==0){ if(s.sigil){s.scene=10;s.xp+=30;} else {startEnemy(s,30);s.scene=9;} }
                else if(i==1){s.scene=11;s.xp+=20;}
                else if(s.mercy || s.wit>=5){s.scene=12;s.xp+=40;msg="Because you chose compassion, the wyrm trusts you.";}
                else {startEnemy(s,30);s.scene=9;msg="Veyrath finds no reason to trust your oath.";}
                break;
            case 9:
                msg=battle(s,i,10,rng); if(s.scene==10 && s.hp>0) msg="The Crown breaks as Veyrath falls."; break;
            case 10: case 11: case 12: case 13:
                if(i==0){s.scene=0;}else{s.clear();return "classes";} break;
        }
        if(s.hp<=0)s.scene=13;
        s.save(); return msg;
    }

    static void startEnemy(GameState s, int hp){ if(s.enemyHp<=0){s.enemyHp=hp;s.enemyMax=hp;} }

    private static String check(GameState s,String stat,int target,Random r){
        int roll=1+r.nextInt(10), total=roll+s.stat(stat);
        return (total>=target?"Success":"Failure")+" — rolled "+roll+" + "+s.stat(stat)+" = "+total+".";
    }

    private static String battle(GameState s,int i,int winScene,Random r){
        if(s.enemyMax==0) startEnemy(s, s.scene==4?18:s.scene==7?22:30);
        if(i==2){
            if(s.potions<=0)return "No potions remain.";
            s.potions--;int heal=8+r.nextInt(5);s.hp=Math.min(s.maxHp,s.hp+heal);return "You recover "+heal+" health.";
        }
        int power = i==0?s.might:("ARCANIST".equals(s.role)?s.wit:s.grace);
        int hit=2+r.nextInt(5)+power+(s.sigil?1:0);s.enemyHp-=hit;
        if(s.enemyHp<=0){s.enemyHp=s.enemyMax=0;s.xp+=25;s.gold+=5;s.scene=winScene;return "Victory! You deal "+hit+" damage.";}
        int incoming=Math.max(1,2+r.nextInt(5)-(s.ward?1:0));s.hp-=incoming;
        return "You deal "+hit+" damage and suffer "+incoming+".";
    }
}
