package com.abdulrahman.ashencrown;

import android.content.Context;
import android.content.SharedPreferences;

final class GameState {
    String hero = "Wanderer";
    String role = "";
    int scene = 0, hp = 20, maxHp = 20, might = 2, wit = 2, grace = 2;
    int gold = 8, potions = 2, xp = 0, enemyHp = 0, enemyMax = 0;
    boolean sigil = false, mercy = false, ward = false;
    private final SharedPreferences p;

    GameState(Context c) { p = c.getSharedPreferences("ashen_save", Context.MODE_PRIVATE); load(); }

    void newGame(String chosenRole) {
        role = chosenRole; scene = 1; hp = maxHp = 20; might = wit = grace = 2;
        gold = 8; potions = 2; xp = 0; sigil = mercy = ward = false; enemyHp = enemyMax = 0;
        if ("WARDEN".equals(role)) { maxHp = hp = 26; might = 4; }
        else if ("ARCANIST".equals(role)) { wit = 5; maxHp = hp = 18; potions = 3; }
        else { grace = 5; gold = 15; maxHp = hp = 21; }
        save();
    }

    int stat(String key) {
        if ("might".equals(key)) return might;
        if ("wit".equals(key)) return wit;
        return grace;
    }

    void save() {
        p.edit().putString("role", role).putInt("scene", scene).putInt("hp", hp)
                .putInt("maxHp", maxHp).putInt("might", might).putInt("wit", wit)
                .putInt("grace", grace).putInt("gold", gold).putInt("potions", potions)
                .putInt("xp", xp).putInt("enemyHp", enemyHp).putInt("enemyMax", enemyMax)
                .putBoolean("sigil", sigil).putBoolean("mercy", mercy).putBoolean("ward", ward).apply();
    }

    void load() {
        role = p.getString("role", ""); scene = p.getInt("scene", 0);
        hp = p.getInt("hp", 20); maxHp = p.getInt("maxHp", 20);
        might = p.getInt("might", 2); wit = p.getInt("wit", 2); grace = p.getInt("grace", 2);
        gold = p.getInt("gold", 8); potions = p.getInt("potions", 2); xp = p.getInt("xp", 0);
        enemyHp = p.getInt("enemyHp", 0); enemyMax = p.getInt("enemyMax", 0);
        sigil = p.getBoolean("sigil", false); mercy = p.getBoolean("mercy", false);
        ward = p.getBoolean("ward", false);
    }

    boolean hasSave() { return !role.isEmpty() && scene > 0; }
    void clear() { p.edit().clear().apply(); role = ""; scene = 0; }
}

