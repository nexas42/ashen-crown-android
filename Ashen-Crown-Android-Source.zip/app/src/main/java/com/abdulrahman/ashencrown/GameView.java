package com.abdulrahman.ashencrown;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import java.util.*;

final class GameView extends View {
    private final Paint p = new Paint(3); private final Paint shade = new Paint();
    private final GameState state; private final Random rng = new Random();
    private final ArrayList<RectF> buttons = new ArrayList<>();
    private Bitmap keep, library, dragon; private String toast=""; private long toastUntil=0;
    private int screen=0; // 0 story, 1 classes, 2 about
    private float den;

    GameView(Context c){super(c);den=getResources().getDisplayMetrics().density;state=new GameState(c);
        keep=load(c,"scene_keep");library=load(c,"scene_library");dragon=load(c,"scene_dragon");
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);}

    private Bitmap load(Context c,String n){int id=getResources().getIdentifier(n,"drawable",c.getPackageName());return BitmapFactory.decodeResource(getResources(),id);}
    private float d(float x){return x*den;}

    @Override protected void onDraw(Canvas c){super.onDraw(c);buttons.clear();
        p.setColor(Color.rgb(10,12,18));c.drawRect(0,0,getWidth(),getHeight(),p);
        if(screen==1){drawClasses(c);return;} if(screen==2){drawAbout(c);return;}
        Story.Page page=state.scene==0?Story.pageTitle(state):Story.page(state); drawStory(c,page);
    }

    private void drawStory(Canvas c, Story.Page page){
        int imageH=(int)Math.min(getHeight()*.37f,d(300));Bitmap b="library".equals(page.image)?library:"dragon".equals(page.image)?dragon:keep;
        if(b!=null){Rect src=new Rect(0,0,b.getWidth(),b.getHeight());Rect dst=new Rect(0,0,getWidth(),imageH);c.drawBitmap(b,src,dst,p);}
        LinearGradient fade=new LinearGradient(0,imageH*.35f,0,imageH,0x00101218,0xFF101218,Shader.TileMode.CLAMP);shade.setShader(fade);c.drawRect(0,0,getWidth(),imageH+2,shade);shade.setShader(null);
        float x=d(24), y=imageH-d(42); text(c,page.chapter,x,y,d(12),0xFFD6A84F,true); y+=d(34);
        y=wrap(c,page.title,x,y,getWidth()-d(48),d(31),0xFFF5E9D0,true,1.0f)+d(14);
        if(state.scene>0 && state.scene<10){drawStats(c,y);y+=d(42);}
        y=wrap(c,page.body,x,y,getWidth()-d(48),d(16),0xFFD8D3C8,false,1.48f)+d(17);
        float bottom=getHeight()-d(22), bh=d(50), gap=d(10);float total=page.choices.length*(bh+gap)-gap;
        float by=Math.max(y,bottom-total);
        for(String choice:page.choices){RectF r=new RectF(x,by,getWidth()-x,by+bh);button(c,r,choice);buttons.add(r);by+=bh+gap;}
        if(System.currentTimeMillis()<toastUntil){p.setColor(0xF0222630);RectF r=new RectF(d(14),d(18),getWidth()-d(14),d(66));c.drawRoundRect(r,d(12),d(12),p);text(c,toast,d(25),d(48),d(13),0xFFF5E9D0,false);postInvalidateDelayed(200);}
    }

    private void drawStats(Canvas c,float y){
        text(c,state.role,d(24),y+d(20),d(12),0xFFD6A84F,true);
        text(c,"♥ "+state.hp+"/"+state.maxHp+"   ✦ "+state.xp+"   ◈ "+state.gold+"   ⚗ "+state.potions,d(120),y+d(20),d(13),0xFFF0E5CE,false);
        p.setColor(0xFF313542);c.drawRect(d(24),y+d(28),getWidth()-d(24),y+d(32),p);p.setColor(0xFF9F3D45);c.drawRect(d(24),y+d(28),d(24)+(getWidth()-d(48))*Math.max(0,state.hp)/(float)state.maxHp,y+d(32),p);
    }

    private void drawClasses(Canvas c){
        text(c,"CHOOSE YOUR PATH",d(24),d(58),d(13),0xFFD6A84F,true);text(c,"Who answers the Crown?",d(24),d(100),d(28),0xFFF5E9D0,true);
        String[] names={"WARDEN","ARCANIST","SHADE"};String[] desc={"26 health · Might 4\nA steadfast fighter with a protective royal ward.","18 health · Wit 5\nA rune scholar with an extra healing potion.","21 health · Grace 5\nA swift infiltrator who begins with extra gold."};
        float y=d(135);for(int i=0;i<3;i++){RectF r=new RectF(d(22),y,getWidth()-d(22),y+d(130));p.setColor(i==0?0xFF222C36:i==1?0xFF29243A:0xFF30252B);c.drawRoundRect(r,d(14),d(14),p);text(c,names[i],d(40),y+d(36),d(18),0xFFD6A84F,true);wrap(c,desc[i],d(40),y+d(64),getWidth()-d(80),d(14),0xFFE2DDD2,false,1.35f);buttons.add(r);y+=d(145);}
        text(c,"Tap a path to begin · Progress autosaves",d(24),getHeight()-d(28),d(12),0xFF8F929B,false);
    }

    private void drawAbout(Canvas c){
        text(c,"ABOUT",d(24),d(58),d(13),0xFFD6A84F,true);text(c,"Ashen Crown",d(24),d(105),d(32),0xFFF5E9D0,true);
        String body="An original single-player fantasy role-playing game created by Abdulrahman Firas Amer.\n\nStory, design, and game direction: Abdulrahman Firas Amer\n\nBuilt as a text-and-illustration adventure. No music, no 3D, no advertising, no analytics, and no internet connection required.\n\nVersion 1.0.0";
        wrap(c,body,d(24),d(150),getWidth()-d(48),d(17),0xFFD8D3C8,false,1.55f);
        RectF r=new RectF(d(24),getHeight()-d(80),getWidth()-d(24),getHeight()-d(28));button(c,r,"Back");buttons.add(r);
    }

    private void button(Canvas c,RectF r,String label){p.setColor(0xFF252935);p.setStyle(Paint.Style.FILL);c.drawRoundRect(r,d(10),d(10),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(1));p.setColor(0xFF5A503D);c.drawRoundRect(r,d(10),d(10),p);p.setStyle(Paint.Style.FILL);text(c,label,r.left+d(18),r.centerY()+d(5),d(15),0xFFF4E8CF,true);text(c,"›",r.right-d(25),r.centerY()+d(6),d(22),0xFFD6A84F,true);}

    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setTypeface(bold?Typeface.create("serif",Typeface.BOLD):Typeface.create("serif",Typeface.NORMAL));p.setTextSize(size);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
    private float wrap(Canvas c,String s,float x,float y,float width,float size,int color,boolean bold,float spacing){p.setTypeface(bold?Typeface.create("serif",Typeface.BOLD):Typeface.create("serif",Typeface.NORMAL));p.setTextSize(size);p.setColor(color);float line=size*spacing;for(String para:s.split("\\n",-1)){if(para.isEmpty()){y+=line;continue;}String cur="";for(String word:para.split(" ")){String next=cur.isEmpty()?word:cur+" "+word;if(p.measureText(next)>width&&!cur.isEmpty()){c.drawText(cur,x,y,p);y+=line;cur=word;}else cur=next;}c.drawText(cur,x,y,p);y+=line;}return y-line;}

    @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();for(int i=0;i<buttons.size();i++)if(buttons.get(i).contains(x,y)){tap(i);break;}return true;}
    private void tap(int i){
        if(screen==1){if(i<3){state.newGame(i==0?"WARDEN":i==1?"ARCANIST":"SHADE");screen=0;toast="Your legend begins.";toastUntil=System.currentTimeMillis()+1800;}}
        else if(screen==2)screen=0;
        else {String result=Story.choose(state,i,rng);if("classes".equals(result))screen=1;else if("about".equals(result))screen=2;else if(!result.isEmpty()&&!"continue".equals(result)){toast=result;toastUntil=System.currentTimeMillis()+2600;}}
        invalidate();
    }
}
