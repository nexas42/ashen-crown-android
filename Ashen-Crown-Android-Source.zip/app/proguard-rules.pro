# No shrinking is required for this compact offline game.

