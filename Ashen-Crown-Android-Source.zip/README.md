# Ashen Crown: A Solo Tale

An original offline, single-player fantasy role-playing game for Android.

**Creator:** Abdulrahman Firas Amer  
**Format:** text choices, painted illustrations, turn-based encounters  
**Audio:** none  
**Network access:** none

## Game features

- Three playable paths: Warden, Arcanist, and Shade
- Branching story with skill checks and multiple endings
- Turn-based combat, items, XP, gold, and character progression
- Autosave plus manual restart
- Fully offline; no ads, analytics, accounts, or permissions
- Original setting, characters, writing, and artwork

## Building

Open the project in Android Studio (Jellyfish or newer), allow Gradle to sync,
then choose **Build > Build APK(s)**. The debug APK is produced at
`app/build/outputs/apk/debug/app-debug.apk`.

