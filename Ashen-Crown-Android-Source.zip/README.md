# Velvet Oaths

An original offline, adults-only dark-romance role-playing game for Android.

**Creator:** @pickl_rick42  
**Cast:** entirely fictional adults aged 29–35  
**Format:** text choices and painted illustrations  
**Audio:** none  
**Network access:** none

## Features

- Three approaches: Challenger, Devotee, and Observer
- A consistent recurring cast with defined appearances and personalities
- Branching trust, desire, and clarity choices with three endings
- Clearly negotiated consensual non-consent roleplay
- Boundaries, traffic-light check-ins, a safeword, and aftercare
- Adaptive text and button sizing for smaller phone screens
- Autosave, no ads, no analytics, and no account requirement

This game does not depict actual non-consent. Intimate moments are suggestive
and fade to black before explicit sexual activity.

## Building

Open the project in Android Studio and build the debug APK, or use the included
GitHub Actions workflow.
